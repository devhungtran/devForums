import React from 'react';
import ReactDOM from 'react-dom/client'
import { Provider } from 'react-redux'
import GLoal from './Global/Global'
import Store from './Redux/store';
import reportWebVitals from './reportWebVitals'
import RoutersClient from './RoutersClient'



const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
        <Provider store={Store}>
                <GLoal>
                    <RoutersClient />
               </GLoal>
        </Provider>
)
reportWebVitals();
