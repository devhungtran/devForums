import {userEffect, useState } from 'react'
import * as Request from '../../utils/request'
import {BsFillCloudCheckFill} from 'react-icons/bs'
import { Link} from 'react-router-dom'
import {useDispatch} from 'react-redux'
import { SignInUser } from '../../Redux/RequestServer'
const SignIn = () =>{ 
               const dispatch = useDispatch()
               const [username, setUsername] = useState("")
               const [password, setPassword] = useState("")
               const [alert,setAlert]= useState(false)
               const [messageAlert, setMessageAlert] = useState("")
               const [succesfully, setSuccesfully] = useState(false)
               const handleCloseAlert = () =>{
                                setAlert(false)
              }
               const handleSubmit = (e) =>{
                              e.preventDefault()
                              setAlert(true)
                              if(!username){
                                             setMessageAlert("Trường tài khoản không được bỏ trống.")
                                             return
                              }
                              if(!password){
                                             setMessageAlert("Trường mật khẩu không được bỏ trống.")
                                             return
                              }
                              const signin = {
                                             username: username,
                                             password: password
                              }
                              SignInUser(signin, dispatch)
                              // Request.post("/signin", signin).then((success) =>{
                              //             console.log(success)
                              //             if(success.data && success.accessToken){
                              //                setSuccesfully(true)
                              //                setMessageAlert("Sai thông tin đăng nhập, hãy kiểm tra lại")  
                              //                return
                              //             }
                              //              if(success .message=== "user is not exits !!!"){
                              //                setSuccesfully(false)
                              //                 setMessageAlert("Sai thông tin đăng nhập, hãy kiểm tra lại")  
                              //                 return
                              //              }
           
                              // }).catch((err) =>{
                              //                setMessageAlert("Sai thông tin đăng nhập, hãy kiểm tra lại")  
                              //                setSuccesfully(false)                                       
                              // })
                             
               }
               return(
                              <div className="sign">
                                             <div className="sign-element">
                                                            <div className="sign-element-content">
                                                                           
                                                            </div>
                                                            <form className="sign-element-form" onSubmit={handleSubmit}>
                                                                           
                                                                           <div className="header">
                                                                                          <span className='header-title'>
                                                                                                       Đăng nhập tài khoản
                                                                                          </span>
                                                                                          <span className="header-sub">
                                                                                                     Xin mời nhập đẩy đủ thông tin.
                                                                                          </span>
                                                                           </div>
                                                                           {alert &&
                                                                                          <div className={ succesfully === true ? "validation successfully": "validation" }> 
                                                                                                         {messageAlert}
                                                                                          </div>
                                                                            }
                                                                           <div className="container">                  
                                                                                          <div className="group">
                                                                                                         <label htmlFor="fullname" className='group-label'>Họ và tên</label>
                                                                                                         <input type="text" className="group-input" value={username} onChange={(e) =>{setUsername(e.target.value)}} placeholder="Nhập tài khoản" />
                                                                                          </div>
                                                                                          <div className="group">
                                                                                                         <label htmlFor="fullname" className='group-label'>Mật khẩu</label>
                                                                                                         <input type="password" className="group-input" value={password} onChange={(e) =>{setPassword(e.target.value)}} placeholder="Nhập mật khẩu" />
                                                                                          </div>
                                                                           </div>
                                                                           <div className="footer">
                                                                                          <button type="submit" className='footer-button'>Đăng nhập</button>
                                                                                          <span className="footer-arrow">
                                                                                                         Bạn đã có tài khoản? <Link to="/signup"> Đăng nhập.</Link>
                                                                                          </span>
                                                                           </div>
                                                            </form>
                                             </div>
                              </div>
               )
}
export default SignIn