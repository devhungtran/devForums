import {userEffect, useState } from 'react'
import * as Request from '../../utils/request'
import { Link } from 'react-router-dom'
const SignUp = () =>{
               const [fullname, setFullname] = useState("")
               const [email, setEmail] = useState("")
               const [username, setUsername] = useState("")
               const [password, setPassword] = useState("")
               const [alert,setAlert]= useState(false)
              const [messageAlert, setMessageAlert] = useState("")
              const [succesfully, setSuccesfully] = useState(false)
              const handleCloseAlert = () =>{
                                setAlert(false)
              }
               const handleSubmit = (e) =>{
                              e.preventDefault()
                              setAlert(true)
                              if(!fullname){
                                             setMessageAlert("Trường họ và tên không được bỏ trống.")
                                             return
                              }
                              if(!email){
                                             setMessageAlert("Trường email không được bỏ trống.")
                                             return
                              }
                              if(!username){
                                             setMessageAlert("Trường tài khoản không được bỏ trống.")
                                             return
                              }
                              if(!password){
                                             setMessageAlert("Trường mật khẩu không được bỏ trống.")
                                             return
                              }
                              const signup = {
                                             fullname: fullname,
                                             email: email,
                                             username: username,
                                             password: password
                              }
                              Request.post("/signup", signup).then((success) =>{
                                      const resMessagge = success.message;

                                      console.log(success);
                                      if(resMessagge === "succesfully !!!!"){
                                        setSuccesfully(true)
                                      }
                                      if(resMessagge == "Username and password cannot be the same !!!"){
                                        setMessageAlert("Mật khẩu không được giống tài khoản!")  
                                        setSuccesfully(false)
                                        return
                                   }
                                      if(resMessagge == "email had exits !!!" ){
                                        setMessageAlert("Email đã tồn tại trong hệ thống!")  
                                        setSuccesfully(false)
                                        return
                                    }
                                    if(resMessagge == "user had exits !!!" ){
                                        setMessageAlert("Tên tài khoản đã tồn tại trong hệ thống !!!")  
                                        setSuccesfully(false)                                       
                                        return
                                    }
                              }).catch((err) =>{
                                           console.log(err.response.data)
                                           const resMessagge = err.response.data.message
                                           if(resMessagge == "Username and password cannot be the same !!!"){
                                                        setMessageAlert("Mật khẩu không được giống tài khoản!")  
                                                        setSuccesfully(false)
                                                        return
                                           }
                                           if(resMessagge == "email had exits !!!" ){
                                             setMessageAlert("Email đã tồn tại trong hệ thống!")  
                                             setSuccesfully(false)
                                             return
                                        }
                                        if(resMessagge == "user had exits !!!" ){
                                             setMessageAlert("Tên tài khoản đã tồn tại trong hệ thống !!!")  
                                             setSuccesfully(false)                                       
                                             return
                                }

                              })
                             
               }
               return(
                              <div className="sign">
                                             <div className="sign-element">
                                                            <div className="sign-element-content">
                                                                           
                                                            </div>
                                                            <form className="sign-element-form" onSubmit={handleSubmit}>
                                                                           
                                                                           <div className="header">
                                                                                          <span className='header-title'>
                                                                                                       Đăng kí tài khoản
                                                                                          </span>
                                                                                          <span className="header-sub">
                                                                                                     Xin mời nhập đẩy đủ thông tin.
                                                                                          </span>
                                                                           </div>
                                                                           {alert &&
                                                                                          <div className={ succesfully === true ? "validation successfully": "validation" }> 
                                                                                                         {messageAlert}
                                                                                          </div>
                                                                            }
                                                                           <div className="container">
                                                                                          <div className="group">
                                                                                                         <label htmlFor="fullname" className='group-label'>Họ và tên</label>
                                                                                                         <input type="text" className="group-input" value={fullname} onChange={(e) =>{setFullname(e.target.value)}} placeholder="Nhập họ và tên"  />
                                                                                          </div>
                                                                                          <div className="group">
                                                                                                         <label htmlFor="fullname" className='group-label'>Email</label>
                                                                                                         <input type="text" className="group-input" value={email} onChange={(e) =>{setEmail(e.target.value)}} placeholder="Nhập email" />
                                                                                          </div>
                                                                                          <div className="group">
                                                                                                         <label htmlFor="fullname" className='group-label'>Họ và tên</label>
                                                                                                         <input type="text" className="group-input" value={username} onChange={(e) =>{setUsername(e.target.value)}} placeholder="Nhập tài khoản" />
                                                                                          </div>
                                                                                          <div className="group">
                                                                                                         <label htmlFor="fullname" className='group-label'>Mật khẩu</label>
                                                                                                         <input type="password" className="group-input" value={password} onChange={(e) =>{setPassword(e.target.value)}} placeholder="Nhập mật khẩu" />
                                                                                          </div>
                                                                           </div>
                                                                           <div className="footer">
                                                                                          <button type="submit" className='footer-button'>Đăng Kí</button>
                                                                                          <span className="footer-arrow">
                                                                                                         Bạn đã có tài khoản? <Link to="/signin"> Đăng nhập.</Link>
                                                                                          </span>
                                                                           </div>
                                                            </form>
                                             </div>
                              </div>
               )
}
export default SignUp