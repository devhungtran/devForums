
import styled from 'styled-components'
const Loading = () =>{                                                                            
               return(
                              <div className="loading">
                                             <div className="loading-infinity">
                                                            <div className="loading-infinity-element"></div>
                                                            <div className="loading-infinity-element"></div>
                                                            <div className="loading-infinity-element"></div>
                                             </div>
                              </div>
               )
}
export default Loading