               const NotFound = () =>{
                              document.title = "404 | Not Found"
               return(
                              <div className="notFound">
                                             <div className="notFound-content">
                                                            <h1>404</h1>
                                                            <span>This page could not be found.</span>
                                             </div>
                              </div>
               )
               }
               export default NotFound