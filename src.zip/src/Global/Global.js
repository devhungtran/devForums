
import '../Global/Global.scss'
const GLoal = ({children}) =>{
               return children
}
export default GLoal