import { useState } from "react"


const  FacebookServices = () =>{
               document.title = "facebook service"
               const [pages, sertPages] = useState("buy")
               const handleChangePaege = () =>{
                              sertPages("history")
               }
               console.log(pages)

               const ServiceBuy = () =>{
                              const [amountOder, setAmountOrder] = useState("1000")
                              const priceOrder = amountOder*6
                              const priceOutPut = priceOrder.toLocaleString()
                              return(
                                       <div className="service-content-market">
                                             <div className="market">
                                                            <form >
                                                                           <div className="market-input">
                                                                                          <div className="market-intput-id">
                                                                                                         
                                                                                          </div>
                                                                                          <div className="market-intput-id">
                                                                                                         
                                                                                          </div> 
                                                                                          <div className="market-intput-amount">
                                                                                                         <label htmlFor="amount">
                                                                                                                  Số lượng
                                                                                                         </label>       
                                                                                                         <input 
                                                                                                                        type="number"
                                                                                                                        id="amount" 
                                                                                                                        value={amountOder}
                                                                                                                        onChange={(e) =>{setAmountOrder(e.target.value)}}
                                                                                                          />
                                                                                          </div>
                                                                                          <div className="market-intput-price">
                                                                                                         Tổng thanh toán: {priceOutPut}              
                                                                                           </div> 
                                                                           </div>
                                                                           <div className="market-output">

                                                                           </div>
                                                            </form>
                                             </div>
                                             <div className="alert">
                                                            <div className="alert-title">
                                                                       Lưu ý !!!
                                                            </div>
                                                            <div className="alert-content">
                                                                           <p>- Nghiêm cấm buff các đơn có nội dung vi phạm pháp luật, chính trị, đồ trụy... Nếu cố tình buff bạn sẽ bị trừ hết tiền và ban khỏi hệ thống vĩnh viễn, và phải chịu hoàn toàn trách nhiệm trước pháp luật.</p>
                                                                           <p>
                                                                           - Nếu đơn đang chạy trên hệ thống mà bạn vẫn mua ở các hệ thống bên khác, nếu có tình trạng hụt, thiếu số lượng giữa 2 bên thì sẽ không được xử lí.
                                                                           </p>
                                                                           <p>
                                                                           - Đơn cài sai thông tin hoặc lỗi trong quá trình tăng hệ thống sẽ không hoàn lại tiền.
                                                                           </p>
                                                                           <p>
                                                                           - Nếu gặp lỗi hãy nhắn tin hỗ trợ phía bên phải góc màn hình hoặc vào mục liên hệ hỗ trợ để được hỗ trợ tốt nhất.
                                                                           </p>
                                                            </div>
                                             </div>
                                       </div>   
                              )
               }

               return(
                              <div className="service">
                                            <div className="service-header">
                                                            <div className="service-header-arrow">
                                                                           Thêm đơn
                                                            </div>
                                                            <div className="service-header-arrow">               
                                                                           Danh sách đơn
                                                            </div>         
                                            </div>
                                            <div className="service-content">
                                                            <ServiceBuy />
                                            </div>
                              </div>
               )
}
export default  FacebookServices