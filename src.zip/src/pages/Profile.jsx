import { HiOutlineUser, HiUsers } from 'react-icons/hi'
import { useEffect ,useState} from 'react'
import wallpaper from '../resources/img/bginfo.jpg'
import vietnam from '../resources/svg/vietnam.svg'
import { IoMailOpen, IoTime } from 'react-icons/io5'
const user = {
               "data": {
                   "order": {
                       "total": 0,
                       "succesfully": 0,
                       "pause": 0,
                       "active": 0,
                       "process": 0
                   },
                   "_id": "6298ab464d6f89fb0063b825",
                   "fullname": "hung tran",
                   "email": "mrthinh028@gmail.com",
                   "username": "devhungtran",
                   "password": "$2b$10$YF7b9sS90VtozsXwhmHBUubjGThpv.Zu8ILD8I3ywkLwSFNk96i/C",
                   "avatar": "https://ui-avatars.com/api/?background=random&name=hung+tran",
                   "isAdmin": false,
                   "isActive": false,
                   "cash": 0,
                   "cashTotarl": 0,
                   "createDate": "2022-06-02T12:21:26.485Z",
                   "updateDate": "2022-06-02T12:21:26.485Z",
                   "__v": 0
               },
               "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRldmh1bmd0cmFuIiwiaXNBZG1pbiI6ZmFsc2UsImlhdCI6MTY1NDIyNjQyNSwiZXhwIjoxNjU0MjUwNDI1fQ.fyq-DZifWlasEqxybaHQKU7gssx6ILGrgY9b8yReJHw"
           }

const Profile = () =>{
               const [IPClient ,setIPClient]  = useState("")
               const [country ,Setcountry]  = useState("")
               useEffect(() => {
                              fetch('https://extreme-ip-lookup.com/json/?key=YjM5CF8Dxi8fyF5KMbla')
                              .then( res => res.json())
                              .then(response => {
                               console.log("Country is : ", response);
                               setIPClient(response.query)
                               Setcountry(response.country)
                             })
                             .catch((data, status) => {
                               console.log('Request failed:', data);
                             });
                           },[])
               return(
                         <div className="profile">
                                        <div className="profile-heading">        
                                        </div>
                                        <div className="profile-container">
                                                       <div className="profile-container-avatar">
                                                                           <img src={user.data.avatar} alt="" /> 
                                                      </div>       
                                                      <div className="profile-container-content">
                                                                     <div className="name">
                                                                                  <h1>
                                                                                                    {user.data.fullname}
                                                                                  </h1>
                                                                     </div>
                                                                     <div className="info">
                                                                                    <div className="info-element">
                                                                                                         <div className="info-element-icon">
                                                                                                                        <HiOutlineUser />
                                                                                                         </div>
                                                                                                         <div className="info-element-content">
                                                                                                                        <div>
                                                                                                                                         Tên tài khoản
                                                                                                                        </div>
                                                                                                                        <div>
                                                                                                                                         @{user.data.username} | id: 1
                                                                                                                        </div>
                                                                                                         </div>
                                                                                    </div>
                                                                                    <div className="info-element">
                                                                                                         <div className="info-element-icon">
                                                                                                                        <IoMailOpen />
                                                                                                         </div>
                                                                                                         <div className="info-element-content">
                                                                                                                        <div>
                                                                                                                           Email
                                                                                                                        </div>
                                                                                                                        <div>
                                                                                                                        {user.data.email}
                                                                                                                        </div>
                                                                                                         </div>
                                                                                    </div>
                                                                                    <div className="info-element">
                                                                                                         <div className="info-element-icon">
                                                                                                                       <div className='vietnam'>
                                                                                                                              <img src={vietnam} alt=""/>
                                                                                                                       </div>
                                                                                                         </div>
                                                                                                         <div className="info-element-content">
                                                                                                                        <div>
                                                                                                                                        IP Đăng nhập
                                                                                                                        </div>
                                                                                                                        <div>
                                                                                                                                        {country} | {IPClient} | 
                                                                                                                        </div>
                                                                                                         </div>
                                                                                    </div>
                                                                                    <div className="info-element">
                                                                                                         <div className="info-element-icon">
                                                                                                                        <HiOutlineUser />
                                                                                                         </div>
                                                                                                         <div className="info-element-content">
                                                                                                                        <div>
                                                                                                                           {user.data.fullname}
                                                                                                                        </div>
                                                                                                                        <div>
                                                                                                                        @{user.data.username} | id: 1
                                                                                                                        </div>
                                                                                                         </div>
                                                                                    </div>
                                                                                    <div className="info-element">
                                                                                                         <div className="info-element-icon">
                                                                                                                        <HiOutlineUser />
                                                                                                         </div>
                                                                                                         <div className="info-element-content">
                                                                                                                        <div>
                                                                                                                           {user.data.fullname}
                                                                                                                        </div>
                                                                                                                        <div>
                                                                                                                        @{user.data.username} | id: 1
                                                                                                                        </div>
                                                                                                         </div>
                                                                                    </div>
                                                                                    <div className="info-element">
                                                                                                         <div className="info-element-icon">
                                                                                                                        <IoTime />
                                                                                                         </div>
                                                                                                         <div className="info-element-content">
                                                                                                                        <div>
                                                                                                                                       Đã tham gia vào
                                                                                                                        </div>
                                                                                                                        <div>
                                                                                                                                        {user.data.createDate}
                                                                                                                        </div>
                                                                                                         </div>
                                                                                    </div>
                                                                     </div>
                                                      </div>
                                        </div>
                                        
                                        
                         </div>
               )
}
export default Profile