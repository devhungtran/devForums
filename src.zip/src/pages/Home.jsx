import charBarImg from '../resources/img/crm-bar-chart.png'
import charLineImg from '../resources/img/crm-line-chart.png'
import {SiWebmoney} from 'react-icons/si'
import * as user from '../services/user'
import *  as request    from '../utils/request'
import { notifications } from '../services/notification'
import { useState ,useEffect} from 'react'
import { AiOutlineComment, AiOutlineShareAlt } from 'react-icons/ai'
import { GiSelfLove } from 'react-icons/gi'
const Home = () =>{
                        const [notification, setNotifications] = useState([]) 
                        useEffect(() =>{
                        request.get("/dev/notification").then((data) =>{
                                   setNotifications(data)
                        }).catch((err) =>{
                              console.log("Err");
                        })
               },[])
               const userData = user.user.data
               return(
                           <div className="home">
                                          <div className="home-welcome">
                                                            <div className="home-welcome-first">
                                                                           <img src={charBarImg} alt="" />
                                                                           <div className="content">
                                                                                          <span>Welcome to</span>
                                                                                          <span>socialmedia<span id='endDmain'>.vn</span></span>
                                                                           </div>
                                                                           <img src={charLineImg} alt="" />
                                                            </div>
                                          </div>
                                         <div className="home-content">
                                                            <div className="home-content-model">
                                                                           <div className="cash">
                                                                                          <div className="cash-element">
                                                                                                         <div className="head">
                                                                                                                  <div className="head-icon">
                                                                                                                        <SiWebmoney />
                                                                                                                  </div>
                                                                                                                  <div className="head-text">
                                                                                                                     Số dư
                                                                                                                  </div>
                                                                                                         </div>
                                                                                                         <div className="content">
                                                                                                                 <span>  {userData.cash}   </span> <span id="currency">HTD</span>
                                                                                                         </div>
                                                                                          </div>
                                                                                          <div className="cash-element">
                                                                                                         <div className="head">
                                                                                                                  <div className="head-icon">
                                                                                                                              <SiWebmoney />
                                                                                                                   </div>
                                                                                                                   <div className="head-text">
                                                                                                                         Nạp tháng
                                                                                                                  </div>
                                                                                                         </div>
                                                                                                         <div className="content">
                                                                                                          
                                                                                                                <span>   {userData.cashMoth}</span>  <span id="currency">HTD</span>
                                                                                                         </div>
                                                                                          </div>
                                                                                          <div className="cash-element">
                                                                                                         <div className="head">
                                                                                                                        <div className="head-icon">
                                                                                                                                    <SiWebmoney />
                                                                                                                        </div>
                                                                                                                        <div className="head-text">
                                                                                                                              Đã nạp
                                                                                                                    </div>
                                                                                                            </div>
                                                                                                         <div className="content">
                                                                                                                  <span>{userData.cashTotarl}</span>  <span id="currency">HTD</span>
                                                                                                         </div>
                                                                                          </div>
                                                                           </div>
                                                                           <div className="notification">
                                                                                    {notification.map((notification, index) =>
                                                                                                <div key={index} className="notification-element"> 
                                                                                                            <div className="notification-element-head">
                                                                                                                              <div className="avatar">
                                                                                                                                    <img src="https://graph.facebook.com/1047660085/picture" alt="" />
                                                                                                                              </div>
                                                                                                                              <div className="content">
                                                                                                                                    <div className="content-author">
                                                                                                                                                <span>
                                                                                                                                                      {notification.createBuy}
                                                                                                                                                </span>
                                                                                                                                                <span className="createDay">
                                                                                                                                                      {notification.createDate}
                                                                                                                                                </span>
                                                                                                                                    </div>
                                                                                                                              </div>
                                                                                                            </div>
                                                                                                            <div className="notification-element-container">
                                                                                                                        <div className="content">
                                                                                                                                    <p>
                                                                                                                                          {notification.content}
                                                                                                                                    </p>
                                                                                                                        </div>
                                                                                                            </div>
                                                                                                            <div className="notification-element-footer">
                                                                                                                     <div className="react">
                                                                                                                              <div className="react-icon">
                                                                                                                                    <GiSelfLove />
                                                                                                                              </div>
                                                                                                                              <div className="react-conent">
                                                                                                                                   {notification.react}
                                                                                                                              </div>
                                                                                                                     </div>
                                                                                                                     <div className="coment">
                                                                                                                              <div className="coment-icon">
                                                                                                                                    <AiOutlineComment />
                                                                                                                              </div>
                                                                                                                              <div className="coment-content">
                                                                                                                                    {notification.coment}
                                                                                                                              </div>
                                                                                                                     </div>
                                                                                                                     <div className="share">
                                                                                                                        <div className="share-icon">
                                                                                                                                          <AiOutlineShareAlt />
                                                                                                                          </div>
                                                                                                                          <div className="share-content">
                                                                                                                                         {notification.share}
                                                                                                                          </div>
                                                                                                                     </div>
                                                                                                            </div>
                                                                                                </div>
                                                                                    )}
                                                                           </div>
                                                            </div>
                                                            <div className="home-content-char"></div>
                                         </div>
                           </div>
               )
}
export default Home