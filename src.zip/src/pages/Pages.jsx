import Home from "./Home"
import { BsFillSunFill, BsGlobe, BsFillMoonStarsFill} from 'react-icons/bs'
import { useState , useEffect} from "react"
import { Routes , Route} from "react-router-dom"
import { Link } from "react-router-dom"
import Recharge from './Recharge'
import logo from '../resources/img/socialmedia.png'
import { FaChessKing, FaHistory } from "react-icons/fa"
import {CgMenuRight} from 'react-icons/cg'
import {HiChartPie} from 'react-icons/hi'
import { SiHomeassistant } from "react-icons/si"
import { RiGlobalFill, RiUserSettingsFill, RiVipCrown2Fill } from "react-icons/ri"
import { GiMoneyStack, GiUpgrade } from "react-icons/gi"
import FacebookServices from "./Services/FacebookServices"
const user = {
               "data": {
                   "order": {
                       "total": 0,
                       "succesfully": 0,
                       "pause": 0,
                       "active": 0,
                       "process": 0
                   },
                   "_id": "6298ab464d6f89fb0063b825",
                   "fullname": "Hung Tran",
                   "email": "mrthinh028@gmail.com",
                   "username": "devhungtran",
                   "password": "$2b$10$YF7b9sS90VtozsXwhmHBUubjGThpv.Zu8ILD8I3ywkLwSFNk96i/C",
                   "avatar": "https://ui-avatars.com/api/?background=random&name=hung+tran",
                   "isAdmin": false,
                   "isActive": false,
                   "cash": 0,
                   "cashTotarl": 0,
                   "createDate": "2022-06-02T12:21:26.485Z",
                   "updateDate": "2022-06-02T12:21:26.485Z",
                   "__v": 0
               },
               "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRldmh1bmd0cmFuIiwiaXNBZG1pbiI6ZmFsc2UsImlhdCI6MTY1NDIyNjQyNSwiZXhwIjoxNjU0MjUwNDI1fQ.fyq-DZifWlasEqxybaHQKU7gssx6ILGrgY9b8yReJHw"
           }
const Pages = () =>{
              const [userSetting, setUserSetting] = useState(false)
               const [light, setLight]  = useState(true)
               const handleChangeThemse = () =>{
                               setLight(!light)
               }
               const [sideBarActive, setSideBarActive]  = useState(false)
               const handleSidebar = () =>{
                      setSideBarActive(!sideBarActive)
               }
               const handleShowSettingUser = () =>{
                            setUserSetting(!userSetting)
               }

               return(
                              <div  className={light === true ? "social": "dark social "}>
                                            <div className={sideBarActive === true ? "social-sidebar active" : "social-sidebar"} >
                                                    <div className="social-sidebar-heading">
                                                            <div className="logo">
                                                                        <img src={logo} alt="" />
                                                            </div>
                                                            <div className="toogle" onClick={handleSidebar}>
                                                                     <CgMenuRight />
                                                            </div>
                                                    </div>
                                                    <div className="social-sidebar-menu">
                                                                <div className="group">
                                                                                <div className="title">
                                                                                        <span>
                                                                                            <HiChartPie />
                                                                                        </span>
                                                                                        <span>
                                                                                            Menu he thong
                                                                                        </span>
                                                                                </div>
                                                                                <ul className="list">
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                     <SiHomeassistant />
                                                                                                </div>
                                                                                                <Link to="/">
                                                                                                    Trang chủ
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                  <div className="icon">
                                                                                                     <RiUserSettingsFill />
                                                                                                </div>
                                                                                                <Link to="/profile/info">
                                                                                                        Tài khoản của tôi
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                        <GiMoneyStack />
                                                                                                </div>
                                                                                                <Link to="/recharge">
                                                                                                       Nạp tiền tài khoản
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                        <FaHistory />
                                                                                                </div>
                                                                                                <Link to="/">                      
                                                                                                        Lịch sử tài khoản
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                         <RiVipCrown2Fill />
                                                                                                </div>
                                                                                                <Link to="/">                                          
                                                                                                        Cấp bậc tài khoản
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                        <RiGlobalFill />
                                                                                                </div>
                                                                                                <Link to="/">
                                                                                                   Tạo website riêng
                                                                                                </Link>
                                                                                        </li>
                                                                                </ul>
                                                                </div>
                                                                <div className="group">
                                                                                <div className="title">
                                                                                        <span>
                                                                                            <HiChartPie />
                                                                                        </span>
                                                                                        <span>
                                                                                                Dịch vụ
                                                                                        </span>
                                                                                </div>
                                                                                <ul className="list">
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                     <SiHomeassistant />
                                                                                                </div>
                                                                                                <Link to="/service/facebook">
                                                                                                   
                                                                                                                Dịch vụ Facebook
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                  <div className="icon">
                                                                                                     <RiUserSettingsFill />
                                                                                                </div>
                                                                                                <Link to="/profile/info">
                                                                                                        Tài khoản của tôi
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                        <GiMoneyStack />
                                                                                                </div>
                                                                                                <Link to="/recharge">
                                                                                                       Nạp tiền tài khoản
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                        <FaHistory />
                                                                                                </div>
                                                                                                <Link to="/">                      
                                                                                                        Lịch sử tài khoản
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                         <RiVipCrown2Fill />
                                                                                                </div>
                                                                                                <Link to="/">                                          
                                                                                                        Cấp bậc tài khoản
                                                                                                </Link>
                                                                                        </li>
                                                                                        <li className="list-item">
                                                                                                <div className="icon">
                                                                                                        <RiGlobalFill />
                                                                                                </div>
                                                                                                <Link to="/">
                                                                                                   Tạo website riêng
                                                                                                </Link>
                                                                                        </li>
                                                                                </ul>
                                                                </div>
                                                    </div>
                                                    
                                            </div>
                                            <div className="social-main">
                                                        <div className="social-main-header">
                                                                        <div className="search">
                                                                            <input type="text" placeholder="Search..." />
                                                                        </div>
                                                                     <div className="control">
                                                                                 <div className="control-themse" onClick={handleChangeThemse}>
                                                                                    {
                                                                                        light === true ? <BsFillMoonStarsFill /> : <BsFillSunFill /> 
                                                                                    }
                                                                                 </div>
                                                                                 <div className="control-user" onClick={handleShowSettingUser}>
                                                                                            {userSetting && 
                                                                                                    <div className="control-user-setting">
                                                                                                        <div className="head">
                                                                                                                <div className="head-icon">
                                                                                                                     <FaChessKing />
                                                                                                                </div>
                                                                                                                <div className="head-text">
                                                                                                                     Nâng cấp bậc
                                                                                                                </div>
                                                                                                        </div>
                                                                                                        <ul className="list">
                                                                                                            <li className="list-item">
                                                                                                                        <a href="#">Tài khoản của tôi</a>
                                                                                                            </li>
                                                                                                            <li className="list-item">
                                                                                                                        <a href="#">Nạp tiền tài khoản</a>
                                                                                                            </li>
                                                                                                            <li className="list-item">
                                                                                                                        <a href="#">Đăng xuất</a>
                                                                                                            </li>
                                                                                                        </ul>
                                                                                                    </div>}
                                                                                            <div className="control-user-avatar">
                                                                                                    <img src={user.data.avatar} alt="avatart" />
                                                                                            </div>
                                                                                            <div className="control-user-info">
                                                                                                                <h6>
                                                                                                                        {user.data.fullname}
                                                                                                                </h6>
                                                                                                    </div>
                                                                                 </div>

                                                                     </div>
                                                        </div>
                                                        <div className="social-main-container">
                                                                           <Routes>
                                                                               <Route path="/" element={<Home />} />
                                                                               <Route path="/recharge" element={<Recharge />} />
                                                                               <Route path="/service/facebook" element={<FacebookServices />} />
                                                                           </Routes>
                                                        </div>
                                            </div>
                              </div>
               )
}
export default Pages