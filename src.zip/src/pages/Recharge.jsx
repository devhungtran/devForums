import { useEffect } from "react"
import { useState } from "react"
import * as request from '../utils/request'
const Recharge = () =>{
               const [pageRecharge, setPageRecharge] = useState(true)
               const [accountBank, setAccountBank] = useState({
                             "first": {
                                             "name": "MB BANK",
                                             "stk": "8886888969",
                                             "ctk": "TRAN NGOC HUNG",
                                             "logo": "https://www.mbbank.com.vn/images/logo.png"
                                           },
                                           "second": {
                                             "name": "VIETCOMBANK",
                                             "stk": "9867707816",
                                             "ctk": "TRAN NGOC HUNG",
                                             "logo": "https://portal.vietcombank.com.vn/Resources/v3/img/logo.png"
                                           },
                                           "third": {
                                             "name": "MOMO",
                                             "stk": "0867707816",
                                             "ctk": "TRAN NGOC HUNG",
                                             "logo": "https://imgur.com/a/DGwXmeG"
                                           },
                                           "fourth": {
                                             "name": "TSR",
                                             "stk": "devhungtran",
                                             "ctk": "TRAN NGOC HUNG",
                                             "logo": "https://thesieure.com/storage/userfiles/images/logo_thesieurecom.png"
                                           }
               })
               const [codeRecharge, setCodeRecharge] = useState("devhungtran")
               useEffect(() =>{
                              request.get('/dev/recharge').then((data) =>{
                                           setAccountBank(data[0].bank)
                                
                              }).catch((err) =>{
                                             alert("err")
                              })
               },[])
               console.log(accountBank)
               return(
                              <div className="recharge">
                                          <div className="recharge-header">
                                                            <div className={ pageRecharge === true ? "recharge-header-banking acctive" : "recharge-header-banking"}>
                                                                               Nạp Tiền
                                                            </div>
                                                            <div className="recharge-header-history">
                                                                              Nhật Ký Nạp Tiền
                                                            </div>
                                          </div>
                                          <div className="recharge-container">
                                                            <div className="title">
                                                                           <span className="title-title">
                                                                                           Tỷ giá: 1 VNĐ = 1 SOL
                                                                           </span>
                                                                           <div className="title-alert">
                                                                                          <p>
                                                                                                                    - Bạn vui lòng chuyển khoản chính xác nội dung để được cộng tiền nhanh nhất.
                                                                                          </p>
                                                                                          <p>
                                                                                                                  - Nếu sau 10 phút từ khi tiền trong tài khoản của bạn bị trừ mà vẫn chưa được cộng tiền vui liên hệ Admin để được hỗ trợ.
                                                                                          </p>
                                                                                          <p>
                                                                                                                  - Vui lòng không nạp từ bank khác qua bank này (tránh lỗi).
                                                                                          </p>
                                                                           </div>
                                                            </div>
                                                            <div className="content">
                                                            <div className="content-group">
                                                                          <div className="element">
                                                                                          <div className="element-img">
                                                                                                         <img src={accountBank.first.logo} alt=""   height="45px"/>
                                                                                          </div>
                                                                                          <div className="group">
                                                                                                         <div className="group-element">
                                                                                                              Số tài khoản: <span>{accountBank.first.stk}</span>
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                               Chủ tài khoản: <span>{accountBank.second.ctk}</span>
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                              Nạp tối thiểu: 10,000 VNĐ
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                              Chú ý: Nạp tốc độ 5s -30s, khung giờ 22h - 24h có thể delay.
                                                                                                         </div>
                                                                                          </div> 
                                                                           </div>
                                                                          <div className="element">
                                                                                          <div className="element-img">
                                                                                                         <img src={accountBank.second.logo} alt=""   height="45px"/>
                                                                                          </div>
                                                                                          <div className="group">
                                                                                                         <div className="group-element">
                                                                                                              Số tài khoản: <span>{accountBank.second.stk}</span>
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                               Chủ tài khoản: <span>{accountBank.second.ctk}</span>
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                              Nạp tối thiểu: 10,000 VNĐ
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                              Chú ý: Nạp tốc độ 5s -30s, khung giờ 22h - 24h có thể delay.
                                                                                                         </div>
                                                                                          </div> 
                                                                           </div>
                                                                    </div>
                                                                    <div className="content-group">
                                                                          <div className="element">
                                                                                          <div className="element-img">
                                                                                                         <img src={accountBank.first.logo} alt=""   height="45px"/>
                                                                                          </div>
                                                                                          <div className="group">
                                                                                                         <div className="group-element">
                                                                                                              Số tài khoản: <span>{accountBank.first.stk}</span>
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                               Chủ tài khoản: <span>{accountBank.second.ctk}</span>
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                              Nạp tối thiểu: 10,000 VNĐ
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                              Chú ý: Nạp tốc độ 5s -30s, khung giờ 22h - 24h có thể delay.
                                                                                                         </div>
                                                                                          </div> 
                                                                           </div>
                                                                          <div className="element">
                                                                                          <div className="element-img">
                                                                                                         <img src={accountBank.fourth.logo} alt=""   height="45px"/>
                                                                                          </div>
                                                                                          <div className="group">
                                                                                                         <div className="group-element">
                                                                                                              Số tài khoản: <span>{accountBank.fourth.stk}</span>
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                               Chủ tài khoản: <span>{accountBank.fourth.ctk}</span>
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                              Nạp tối thiểu: 10,000 VNĐ
                                                                                                         </div>
                                                                                                         <div className="group-element">
                                                                                                              Chú ý: Nạp tốc độ 5s -30s, khung giờ 22h - 24h có thể delay.
                                                                                                         </div>
                                                                                          </div> 
                                                                           </div>
                                                                    </div>
                                                            </div>
                                          </div>
                                          
                              </div>
               )
}
export default Recharge