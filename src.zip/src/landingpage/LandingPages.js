import React from 'react'
import Dreamy from "./Dreamy/Dreamy"
import { useEffect, useState} from 'react'
import { Route } from "react-router-dom"
const LandingPages = () =>{
       
               return(
                         <Dreamy />
               )
}
export default  LandingPages