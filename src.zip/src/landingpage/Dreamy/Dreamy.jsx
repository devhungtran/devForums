
import './styles/styles.scss'
import Element from './Element'
import { Routes } from 'react-router-dom'
import { Route } from 'react-router-dom' 
const Dreamy = ()=>{          
               return(
                              <Element />
               )
}
export default Dreamy