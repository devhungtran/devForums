
import './styles/styles.scss'
import React from 'react'
import HeaderDreamy from './components/HeaderDreamy'
import ContainerDreamy from './components/ContainerDreamy'
import FooterDreamy from './components/FooterDreamy'
const Element = ()=>{      
             
               return(
                              <div className="dreamy">
                                                 <HeaderDreamy /> <ContainerDreamy/>   <FooterDreamy />       
                              </div>
               )
}
export default Element