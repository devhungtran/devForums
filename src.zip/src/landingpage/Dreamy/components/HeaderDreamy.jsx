import shape3 from '../resources/img/shape3.png'
import contentImages from '../resources/img/header-img.png'
import {GiTrophy} from 'react-icons/gi'
import { Link } from 'react-router-dom'
import {AiFillStar} from 'react-icons/ai'
const HeaderDreamy = () =>{
               return(
                              <div className="dreamy-header">
                                                            <div className="shape-2 shape">
                                                               
                                                            </div>
                                                            <div className="shape-3 shape">
                                                            <img src={shape3} alt="" />
                                                            </div>
                                                            <div className="heading">
                                                                           <div className="heading-logo">SOCIALMEDIA.VN</div>
                                                                           <div className="heading-navbar">
                                                                                          <ul className="list">
                                                                                                         <li className="list-item">
                                                                                                                        <Link to="/home" >Trang Chủ </Link>
                                                                                                         </li>
                                                                                                         <li className="list-item">
                                                                                                                        <a href="#">Dịch Vụ Nổi Bật</a>
                                                                                                         </li>
                                                                                                         <li className="list-item">
                                                                                                                        <a href="#">Liên Hệ Hỗ Trợ</a>
                                                                                                         </li>
                                                                                          </ul>
                                                                           </div>
                                                                           <div className="heading-arrow">
                                                                                          <ul className="list">
                                                                                                         <li className="list-item">
                                                                                                                        <Link to="/signin" >Đăng Nhập </Link>
                                                                                                         </li>
                                                                                                         <li className="list-item">
                                                                                                                       <Link to="/signup" >Đăng Kí </Link>
                                                                                                         </li>
                                                                                          </ul>
                                                                           </div>
                                                            </div>
                                                            
                                                            <div className="content">
                                                                           <div className="content-text">
                                                                                          <div className="content-text-welcome"> 
                                                                                                         <div className="cup">
                                                                                                                  <div className="icon">
                                                                                                                  <GiTrophy />
                                                                                                                  </div>
                                                                                                                  <div className="text">Top 1 services</div>
                                                                                                         </div>
                                                                                                         <div className="star">
                                                                                                                        <div className="icon">
                                                                                                                                       <AiFillStar></AiFillStar>
                                                                                                                                       <AiFillStar></AiFillStar>
                                                                                                                                       <AiFillStar></AiFillStar>
                                                                                                                                       <AiFillStar></AiFillStar>
                                                                                                                                       <AiFillStar></AiFillStar>
                                                                                                                        </div>    
                                                                                                                        <div className="text">19.083+  reviews</div>
                                                                                                                        
                                                                                                         </div>
                                                                                           </div>
                                                                                          <h1 className="content-text-title">Tạo hiệu ứng cho sự nổi tiếng của bạn</h1>
                                                                                          <p className="content-text-p">Hệ thống chuyên cung cấp các dịch vụ tăng Like, Follow, Share, Comment, View Video,... cho các Mạng xã hội như Facebook, Instagram, Tiktok...</p>
                                                                                          <div className="content-text-arrow">
                                                                                                         <ul className="list">
                                                                                                                        <li className="list-item">
                                                                                                                                       <Link to="/signin" >Đăng Nhập </Link>
                                                                                                                        </li>
                                                                                                                        <li className="list-item">
                                                                                                                                       <Link to="/signup" >Đăng Kí </Link>
                                                                                                                        
                                                                                                                        </li>
                                                                                                         </ul>
                                                                                          </div>
                                                                           </div>
                                                                           <div className="content-img">
                                                                                          <img src={contentImages} alt="" />
                                                                           </div>
                                                            </div>
                                             </div>
               )
}
export default HeaderDreamy