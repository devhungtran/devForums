
const FooterDreamy  = () =>{
               return(
                              <div className="dreamy-footer">
                                             
                              </div>
                              )
}
export default FooterDreamy