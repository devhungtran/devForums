
import {FaHeadset} from 'react-icons/fa'
import {BsShieldLock,BsFillPatchCheckFill} from 'react-icons/bs'
import {BiLogIn} from 'react-icons/bi'
import {HiShoppingCart} from 'react-icons/hi'
import howToWork from  '../resources/img/how-it-works-image.png'
import shape3 from '../resources/img/shape3.png'
import shape6    from '../resources/img/06.png'
import contactImg from '../resources/img/contact-img.png'
import shape7    from '../resources/img/07.png'
import { useEffect,useState } from 'react'

const ContainerDreamy = () =>{
              const [features, setFeatures] = useState(false)
              const [prices, setPrices] = useState(false)
              const [imgContact, setImgContact] = useState(false)
              useEffect(() =>{
                    const handleScroll =() =>{
                          console.log(window.scrollY)
                          if(window.scrollY >=301){
                                setFeatures(true)
                          }else{
                                setFeatures(false)
                          }
                          if(window.scrollY >=2095){
                              setPrices(true)
                        }else{
                              setPrices(false)
                        }
                           if(window.scrollY >=2925){
                              setImgContact(true)
                        }else{
                              setImgContact(false)
                        }
                    }
                    document.addEventListener("scroll", handleScroll)
              },[])
               return(
                              <div className="dreamy-container">
                                             <div className="features">
                                                            <div className="features-title">
                                                                           <span>
                                                                           TÍNH NĂNG CỐT LỖI
                                                                           </span>
                                                                           <h1>
                                                                           Các tính năng ứng dụng tuyệt vời
                                                                           </h1>
                                                                           <p>Với hàng loạt các dịch vụ của chúng tôi cung cấp với những tính năng tuyệt vời, đem lại chất lượng dịch vụ tốt nhất. Bạn có thể sử dụng tất cả các dịch vụ đó bất kể khách hàng của bạn là ai!</p>
                                                            </div>
                                                            {features && 
                                                                                         <div className="features-content">

                                                            <div className="content">
                                                                           <div className="content-icon">
                                                                                      <div className="icon">
                                                                                             <FaHeadset />
                                                                                       </div>
                                                                           </div>
                                                                           <div className="content-title">
                                                                                    Công nghệ
                                                                           </div>
                                                                           <div className="content-content">
                                                                                 Hệ thống được vận hành hoàn toàn tự động 24/24, Using Mern Stack.
                                                                           </div>
                                                            </div>

                                                            <div className="content">
                                                                           <div className="content-icon">
                                                                                      <div className="icon">
                                                                                             <BsShieldLock />
                                                                                       </div>
                                                                           </div>
                                                                           <div className="content-title">
                                                                                 Bảo mật
                                                                           </div>
                                                                           <div className="content-content">
                                                                               Chúng tôi cam kết sẽ bảo mật thông tin người dùng 1 cách tốt nhất.
                                                                           </div>
                                                            </div>

                                                            <div className="content">
                                                                           <div className="content-icon">
                                                                                       <div className="icon">
                                                                                             <FaHeadset />
                                                                                       </div>
                                                                           </div>
                                                                           <div className="content-title">
                                                                                 Hỗ trợ
                                                                           </div>
                                                                           <div className="content-content">
                                                                                   Đội ngũ hỗ trợ luôn lắng nghe ý khiến khách hàng để phát triển hệ thống.
                                                                           </div>
                                                            </div>


                                             </div>}
                                             </div>
                                            


                                          <div className="tutorial">
                                      
                                                      <div className="shape-1">
                                                            <img src={shape6} alt="" />
                                                      </div>
                                                      <div className="shape-2">
                                                            <img src={shape7} alt="" />
                                                      </div>
                                                      <div className="shape-3">
                                                            <img src={shape6} alt="" />
                                                      </div>
                                                      <div className="shape-4">
                                                            <img src={shape7} alt="" />
                                                      </div>
                                                <div className="tutorial-title">
                                                                <span>QUÁ TRÌNH LÀM VIỆC</span>
                                                                <h1>Làm thế nào nó hoạt động?</h1>
                                                                 <p>Thật dễ dàng so với những gì bạn nghĩ. Chỉ cần 3 bước đơn giản</p>
                                                </div>
                                                <div className="tutorial-content">
                                                     <img src={shape3}    className="shape-rotate" />
                                                      <div className="tutorial-content-header">
                                                            <div className="step">
                                                               <div className="step-icon"><BsFillPatchCheckFill /></div> TRUY CẬP WEBSITE
                                                            </div>
                                                            <div className="step">
                                                             
                                                                  <div className="step-icon">
                                                                        <BiLogIn />
                                                                  </div>
                                                                 ĐĂNG KÝ TÀI KHOẢN
                                                            </div>
                                                            <div className="step">
                                                            <div className="step-icon">
                                                                        <HiShoppingCart />
                                                            </div>
                                                             TRUY CẬP DỊCH VỤ
                                                            </div>
                                                      </div>
                                                      <div className="tutorial-content-text">
                                                                  <div className="left">
                                                                       <div className="left-text">
                                                                               <h1>Login Account</h1>
                                                                              <p>Innovative solutions with the best. Incididunt dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor tempor incididunt ut labore et dolore</p>
                                                                              <p>Adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor tempor incididunt ut labore et dolore Innovative solutions with the best. Incididunt dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor tempor incididunt ut labore et dolore</p>
                                                                              <p>Adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor tempor incididunt ut labore et dolore Innovative solutions with the best. Incididunt dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor tempor incididunt ut labore et dolore</p>
                                                                       </div>
                                                                  </div>
                                                                  <div className="img">
                                                                        <img src={howToWork} alt="" />
                                                                  </div>
                                                      </div>
                                                </div>
                                          </div>


                                             <div className="prices">
                                                            <div className="prices-title">
                                                                           <span>BẢNG GIÁ VÀ ƯU ĐÃI</span>
                                                                           <h1>Cấp bậc ưu đãi khách hàng</h1>
                                                                           <p>Sau đây là những ưu đãi mà chúng tôi đưa ra tùy vào cấp bậc của quý khách hàng</p>
                                                            </div>
                                                            {
                                                                  prices &&
                                                                  <div className="content">
                                                                      <div className="content-price">
                                                                           <div className="price-content-title">
                                                                                          Cộng tác viên
                                                                                          </div>
                                                                                          <div className="price-content-price">
                                                                                                <span>0$/ <sub>Years</sub></span>
                                                                                          </div>
                                                                                          <div className="price-content-title">
                                                                                                         <p>Ưu đãi về giá</p>
                                                                                                         <p>Hỗ trợ đặt biệt 24/7</p>
                                                                                                         <p>Có website riêng</p>
                                                                                                         <p>Có nhóm riêng dành cho VIP</p>
                                                                                                         <p>Không quà truy ân ngày lễ đặt biệt</p>
                                                                                          </div>
                                                                                          <div className="price-content-arrow">
                                                                                                         <a href="#">Xem ngay</a>
                                                                                          </div>
                                                                               </div>
                                                                               <div className="content-price">
                                                                           <div className="price-content-title">
                                                                                          <span className="title">
                                                                                                Cộng tác viên
                                                                                          </span>
                                                                                          </div>
                                                                                          <div className="price-content-price">
                                                                                                  <span>99$/ <sub>Years</sub></span>
                                                                                          </div>
                                                                                          <div className="price-content-title">
                                                                                                         <p>Ưu đãi về giá</p>
                                                                                                         <p>Hỗ trợ đặt biệt 24/7</p>
                                                                                                         <p>Có website riêng</p>
                                                                                                         <p>Có nhóm riêng dành cho VIP</p>
                                                                                                         <p>Không quà truy ân ngày lễ đặt biệt</p>
                                                                                          </div>
                                                                                          <div className="price-content-arrow">
                                                                                                         <a href="#">Xem ngay</a>
                                                                                          </div>
                                                                               </div>
                                                                               <div className="content-price">
                                                                           <div className="price-content-title">
                                                                                          Cộng tác viên
                                                                                          </div>
                                                                                          <div className="price-content-price">
                                                                                                        <span>499$/ <sub>Years</sub></span>
                                                                                          </div>
                                                                                          <div className="price-content-title">
                                                                                                         <p>Ưu đãi về giá</p>
                                                                                                         <p>Hỗ trợ đặt biệt 24/7</p>
                                                                                                         <p>Có website riêng</p>
                                                                                                         <p>Có nhóm riêng dành cho VIP</p>
                                                                                                         <p>Không quà truy ân ngày lễ đặt biệt</p>
                                                                                          </div>
                                                                                          <div className="price-content-arrow">
                                                                                                         <a href="#">Xem ngay</a>
                                                                                          </div>
                                                                               </div>
                                                                    </div>
                                                            }
                                             </div>
                                             <div className="sendmail">
                                                      <div className="shape-1">
                                                                  <img src={shape6} alt="" />
                                                            </div>
                                                            <div className="shape-2">
                                                                  <img src={shape7} alt="" />
                                                            </div>
                                                            <div className="shape-3">
                                                                  <img src={shape6} alt="" />
                                                            </div>
                                                            <div className="shape-4">
                                                                  <img src={shape7} alt="" />
                                                            </div>
                                                   <div className="sendmail-left">
                                                      <div className="sendmail-title">
                                                            <span>
                                                                  CONTACT US
                                                            </span>
                                                            <h1>Get In Touch</h1>
                                                            <p>Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolor tempor incididunt ut labore dolore magna.</p>
                                                      </div>
                                                      <form action="mailto:devhungtran@gmail.com" method='POST' className='sendmail-form'>
                                                                  <div className="form-head">
                                                                        <input type="text" placeholder='Ten cua ban' />
                                                                        <input type="text" placeholder='Dia chi email cua ban' />
                                                                  </div>
                                                                  <div className="form-massage">
                                                                        <textarea type="text" placeholder='massenger' />
                                                                  </div>
                                                                  <div className="form-button">
                                                                        <input type="submit" value="Lien he ngay" />
                                                                        <input type="reset" value="Delete all massage" />
                                                                  </div>
                                                                 
                                                      </form>
                                                   </div>
                                                  <div className="sendmail-right">
                                                      {
                                                            imgContact &&
                                                            <img src={contactImg} alt="" />
                                                      }
                                                  </div>
                                             </div>


                                    </div>
               )
}
export default ContainerDreamy