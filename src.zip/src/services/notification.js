
import * as request from '../utils/request'

export const notifications = 

[
               {
                 "_id": "62a254fb9b96ad70781b026c",
                 "content": "social media is system was create in   2022 by devhungtran",
                 "createBuy": "Hung Tran",
                 "react": 1908,
                 "coment": 0,
                 "share": 291,
                 "createDate": "2022-06-09T20:15:55.600Z",
                 "__v": 0
               },
               {
                 "_id": "62a255979b96ad70781b026e",
                 "content": "SOCIALMEDIA.VN ĐÃ ĐỔI MOMO MỚI: 0867707816 - TRAN NGOC HUNG",
                 "createBuy": "Hung Tran",
                 "react": 1908,
                 "coment": 0,
                 "share": 291,
                 "createDate": "2022-06-09T20:18:31.527Z",
                 "__v": 0
               },
               {
                 "_id": "62a255a99b96ad70781b0270",
                 "content": "Hạ giá và tăng tốc độ dịch vụ Facebook sub quality Sv2: - Tốc độ lên ổn ngày 3k -> 10k, sub via nên gần như không tụt, loại sub này max 100k (bảo hành 3 tháng). Sv3: - Tốc độ lên ổn ngày 3k -> 5k, sub via nên gần như không tụt, loại sub này max 100k (bảo hành 1 tháng).",
                 "createBuy": "Hung Tran",
                 "react": 1908,
                 "coment": 0,
                 "share": 291,
                 "createDate": "2022-06-09T20:18:49.998Z",
                 "__v": 0
               }
             ]