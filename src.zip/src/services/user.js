export const user  =  {
               "data": {
                   "order": {
                       "total": 0,
                       "succesfully": 0,
                       "pause": 0,
                       "active": 0,
                       "process": 0
                   },
                   "_id": "6298ab464d6f89fb0063b825",
                   "fullname": "Hung Tran",
                   "email": "mrthinh028@gmail.com",
                   "username": "devhungtran",
                   "password": "$2b$10$YF7b9sS90VtozsXwhmHBUubjGThpv.Zu8ILD8I3ywkLwSFNk96i/C",
                   "avatar": "https://ui-avatars.com/api/?background=random&name=hung+tran",
                   "isAdmin": false,
                   "isActive": false,
                   "cash": 19.482,
                   "cashTotarl": "5.1214.25",
                   "cashMoth": "928.034",
                   "createDate": "2022-06-02T12:21:26.485Z",
                   "updateDate": "2022-06-02T12:21:26.485Z",
                   "__v": 0
               },
               "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRldmh1bmd0cmFuIiwiaXNBZG1pbiI6ZmFsc2UsImlhdCI6MTY1NDIyNjQyNSwiZXhwIjoxNjU0MjUwNDI1fQ.fyq-DZifWlasEqxybaHQKU7gssx6ILGrgY9b8yReJHw"
           }