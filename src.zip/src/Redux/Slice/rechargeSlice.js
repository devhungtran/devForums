import { createSlice } from "@reduxjs/toolkit";

const authSlice = createSlice({
               name: "recharge",
               initialState: {
                              rercharge:{
                                             currenUser: null,
                                             isFetching: false,
                                             error: false
                              }
               },
               reducers:{
                              SigninStart: (state) =>{
                                             state.signin.isFetching = true;
                              },
                              SigninSucessfully: (state, action) =>{
                                             state.signin.isFetching = false
                                             state.signin.currenUser = action.payload
                                             state.signin.error = false
                              },
                              SigninFailed: (state) =>{
                                             state.signin.isFetching = false
                                             state.signin.error = true
                              }
               }
})
export const {
               SigninStart, SigninSucessfully, SigninFailed
} =  authSlice.actions
export default authSlice.reducer