import * as request from '../utils/request'
import { SigninFailed, SigninStart, SigninSucessfully } from './authSlice'
export const SignInUser = async (signin, dispatch) =>{
               dispatch(SigninStart())
               try {
                              const res =  await request.post("/signin", signin)
                              dispatch(SigninSucessfully(res.data))
               } catch (error) {
                              dispatch(SigninFailed())
               }
}              