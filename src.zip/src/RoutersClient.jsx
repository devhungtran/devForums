import { BrowserRouter as Routers } from "react-router-dom"
import { Routes , Route} from "react-router-dom"
import { useEffect, useState} from 'react'
import SignUp from "./components/authencations/SignUp"
import LandingPages from "./landingpage/LandingPages"
import Pages from "./pages/Pages"
import NotFound from "./Global/NotFound/NotFound"
import * as request from './utils/request'
import Recharge from "./pages/Recharge"
import Loading from "./Global/Loading/Loading"
import SignIn from "./components/authencations/SignIn"
import FacebookServices from "./pages/Services/FacebookServices"
const RoutersClient = () =>{
               const [isLogin, setIsLogin] =  useState(false)
               const [loading, setLoading] = useState(true)
               useEffect(() =>{
                              request.get("/dev/socialmedia").then((data)=>{
                                             setLoading(false)
                              }).catch((err) =>{
                                             setLoading(false)
                              })
               },[])
               return(
                              <Routers> 
                                     {loading === true ? <Loading /> : 
                                       <Routes>
                                       <Route path="*" element={<NotFound />} />
                                      <Route  path="/signup" element={<SignUp />} />
                                      <Route  path="/signin" element={<SignIn />} />
                                      
                                      <Route  path="/" element={isLogin === true ? <Pages /> : <LandingPages />} >
                                        <Route path="/recharge" element={<Recharge />} />
                                        <Route path="/service/facebook" element={<FacebookServices />} />
                                      </Route>
                                      </Routes>}
                                </Routers>

               )
}
export default RoutersClient